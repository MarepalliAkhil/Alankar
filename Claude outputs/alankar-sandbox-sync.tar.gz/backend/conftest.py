"""Shared pytest fixtures."""

import pytest
from django.core.cache import cache
from django.test import Client
from django.test.client import MULTIPART_CONTENT
from django.utils import timezone

from accounts.models import User

PASSWORD = "Strong-Pass-2026!"


@pytest.fixture(autouse=True)
def _no_real_smtp(settings):
    """Tests never depend on the developer's .env email settings; email tests opt in."""
    settings.SALON_SMTP_CONFIGURED = False
    settings.EMAIL_BACKEND = "django.core.mail.backends.locmem.EmailBackend"
    # The emailed sign-in code has its own tests (accounts/tests/test_otp.py); everywhere else
    # customers sign in with a password only.
    settings.SALON_CUSTOMER_OTP = False


@pytest.fixture(autouse=True)
def _clear_cache():
    """Rate-limit counters live in the cache; start every test clean."""
    cache.clear()
    yield
    cache.clear()


@pytest.fixture(autouse=True)
def _empty_bodies_are_not_multipart(monkeypatch):
    """The Django test client labels a body-less POST as multipart/form-data and sends a boundary.

    The API accepts JSON only (see core/tests/test_security_headers.py), so a body-less call in a
    test is sent the way the browser app sends it: no body. Real form/multipart bodies are still
    sent unchanged and are refused with 415.
    """
    default_types = {"post": MULTIPART_CONTENT, "put": "application/octet-stream"}
    default_types["patch"] = default_types["delete"] = "application/octet-stream"
    for name, default in default_types.items():
        original = getattr(Client, name)

        def wrapper(
            self,
            path,
            data=None,
            content_type=default,
            *args,
            _orig=original,
            _default=default,
            **kw,
        ):
            if data in (None, "", {}) and content_type == _default:
                return _orig(self, path, "", "application/json", *args, **kw)
            return _orig(self, path, data, content_type, *args, **kw)

        monkeypatch.setattr(Client, name, wrapper)


@pytest.fixture
def make_user(db):
    def _make(
        role="customer",
        email=None,
        password=PASSWORD,
        active=True,
        full_name="Test User",
        verified=True,
    ):
        email = email or f"{role}-{User.objects.count() + 1}@example.com"
        user = User(username=email, email=email, role=role, is_active=active, full_name=full_name)
        if verified:
            user.email_verified_at = timezone.now()
        user.set_password(password)
        user.save()
        return user

    return _make


def login(client: Client, user: User, role: str | None = None, password: str = PASSWORD):
    return client.post(
        "/api/auth/login/",
        {"role": role or user.role, "email": user.email, "password": password},
        content_type="application/json",
    )


@pytest.fixture
def logged_in(make_user):
    """Returns a function role -> (client, user) with an authenticated session cookie."""

    def _logged_in(role: str):
        user = make_user(role=role)
        client = Client()
        response = login(client, user)
        assert response.status_code == 200, response.content
        return client, user

    return _logged_in
